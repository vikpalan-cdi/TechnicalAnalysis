# BDA400 Assignment 2 - reusable stock-analysis functions
# Student: Vikas Palan
# Source: quantmod Yahoo Finance daily OHLCV data

require_analysis_packages <- function() {
  required <- c("quantmod", "TTR", "xts", "zoo")
  missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Install missing packages: ", paste(missing, collapse = ", "))
  invisible(TRUE)
}

read_portfolio <- function(path = "portfolio.txt") {
  if (!file.exists(path)) stop("Portfolio file not found: ", path)
  symbols <- trimws(sub("#.*$", "", readLines(path, warn = FALSE)))
  symbols <- unique(toupper(symbols[nzchar(symbols)]))
  if (!length(symbols)) stop("Portfolio contains no symbols.")
  if (any(!grepl("^[A-Z0-9^][A-Z0-9.^=-]*$", symbols))) {
    stop("Invalid symbol format. Use one ticker per line without a header.")
  }
  symbols
}

# Return a named list of separate data frames, plus a download manifest.
# fetcher can be replaced in offline tests; ordinary runs use quantmod.
load_stock_data <- function(portfolio_file = "portfolio.txt",
                            from = "2025-01-01", to = "2026-01-01",
                            fetcher = NULL) {
  require_analysis_packages()
  symbols <- read_portfolio(portfolio_file)
  from <- as.Date(from); to <- as.Date(to)
  if (length(from) != 1L || length(to) != 1L || is.na(from) || is.na(to) || from >= to) {
    stop("Use valid dates with from earlier than to.")
  }
  if (is.null(fetcher)) {
    fetcher <- function(symbol, from, to) {
      quantmod::getSymbols(symbol, src = "yahoo", from = from, to = to,
                          auto.assign = FALSE, warnings = TRUE)
    }
  }
  frames <- list(); manifest <- list()
  for (symbol in symbols) {
    result <- tryCatch({
      raw <- fetcher(symbol, from, to)
      if (!xts::is.xts(raw) || !NROW(raw)) stop("No xts market data returned.")
      adj <- tryCatch(as.numeric(quantmod::Ad(raw)),
                      error = function(e) rep(NA_real_, NROW(raw)))
      frame <- data.frame(
        Date = as.Date(zoo::index(raw)),
        Open = as.numeric(quantmod::Op(raw)),
        High = as.numeric(quantmod::Hi(raw)),
        Low = as.numeric(quantmod::Lo(raw)),
        Close = as.numeric(quantmod::Cl(raw)),
        Volume = as.numeric(quantmod::Vo(raw)),
        Adjusted = adj
      )
      # Explicit half-open date interval, independent of provider endpoint details.
      frame <- frame[frame$Date >= from & frame$Date < to, , drop = FALSE]
      frame <- frame[order(frame$Date), , drop = FALSE]
      rownames(frame) <- NULL
      if (!nrow(frame)) stop("No observations in the requested date interval.")
      if (anyNA(frame$Date) || anyDuplicated(frame$Date)) stop("Invalid or duplicate dates.")
      if (any(!is.finite(frame$Close) | frame$Close <= 0)) {
        stop("Close prices contain missing, nonfinite, or nonpositive values; review the source.")
      }
      frames[[symbol]] <- frame
      data.frame(Symbol = symbol, Status = "OK", Rows = nrow(frame),
                 FirstDate = as.character(min(frame$Date)),
                 LastDate = as.character(max(frame$Date)), Message = "",
                 stringsAsFactors = FALSE)
    }, error = function(e) {
      data.frame(Symbol = symbol, Status = "FAILED", Rows = 0L,
                 FirstDate = NA_character_, LastDate = NA_character_,
                 Message = conditionMessage(e), stringsAsFactors = FALSE)
    })
    manifest[[symbol]] <- result
  }
  list(data = frames, manifest = do.call(rbind, unname(manifest)),
       requested_from = from, requested_to_exclusive = to)
}

# All tied modal values are returned. All-unique values have no useful mode.
# Do not use base R mode(), which describes an object's storage mode.
statistical_mode <- function(x) {
  if (!is.numeric(x) || !length(x) || any(!is.finite(x))) stop("Mode requires finite numeric values.")
  values <- sort(unique(x))
  counts <- tabulate(match(x, values), nbins = length(values))
  if (max(counts) == 1L) return(numeric(0))
  values[counts == max(counts)]
}

calculate_statistics <- function(stock_data, symbol, window = 20L) {
  require_analysis_packages()
  if (!is.data.frame(stock_data) || !all(c("Date", "Close") %in% names(stock_data))) {
    stop("Provide a data frame with Date and Close columns.")
  }
  if (length(symbol) != 1L || is.na(symbol) || !nzchar(symbol)) stop("Provide one symbol.")
  if (length(window) != 1L || !is.numeric(window) || !is.finite(window) ||
      window < 1 || window != as.integer(window)) stop("Window must be a positive integer.")
  window <- as.integer(window)
  if (nrow(stock_data) < window) stop("Insufficient observations for the moving-average window.")
  x <- stock_data$Close
  if (!is.numeric(x) || any(!is.finite(x) | x <= 0)) stop("Close must contain positive finite numeric values.")
  if (!inherits(stock_data$Date, "Date") || anyNA(stock_data$Date) ||
      anyDuplicated(stock_data$Date) || is.unsorted(stock_data$Date)) {
    stop("Dates must be valid, unique, and sorted.")
  }
  modes <- statistical_mode(x)
  sma <- as.numeric(TTR::SMA(x, n = window))
  summary <- data.frame(
    Symbol = symbol, Observations = length(x),
    FirstDate = min(stock_data$Date), LastDate = max(stock_data$Date),
    MeanClose = mean(x), MedianClose = stats::median(x),
    ModeClose = if (length(modes)) paste(format(modes, digits = 15, trim = TRUE), collapse = "; ") else NA_character_,
    ModeStatus = if (length(modes)) "Repeated value(s)" else "No mode: all values unique",
    SampleSDClose = if (length(x) > 1L) stats::sd(x) else NA_real_,
    SMAWindow = window, LatestSMA = tail(sma, 1),
    stringsAsFactors = FALSE
  )
  list(summary = summary, series = data.frame(Date = stock_data$Date, Close = x, SMA = sma))
}

display_stock_data <- function(stock_frames, n = 6L, viewer = FALSE) {
  if (!length(stock_frames)) stop("No stock data frames to display.")
  for (symbol in names(stock_frames)) {
    cat("\n", symbol, " - ", nrow(stock_frames[[symbol]]), " trading observations\n", sep = "")
    cat("First rows\n"); print(utils::head(stock_frames[[symbol]], n), row.names = FALSE)
    cat("Latest rows\n"); print(utils::tail(stock_frames[[symbol]], n), row.names = FALSE)
    if (viewer && interactive()) utils::View(stock_frames[[symbol]], title = paste(symbol, "daily data"))
  }
  invisible(stock_frames)
}

display_statistics <- function(results) {
  summary <- do.call(rbind, lapply(results, `[[`, "summary"))
  rownames(summary) <- NULL
  cat("\nClosing-price statistics (USD); sample standard deviation; unrounded source prices\n")
  print(summary, row.names = FALSE, digits = 6)
  invisible(summary)
}

plot_stock_data <- function(result, symbol, file = NULL) {
  if (!is.null(file)) {
    grDevices::png(file, width = 1600, height = 900, res = 160)
    on.exit(grDevices::dev.off(), add = TRUE)
  }
  series <- result$series
  graphics::plot(series$Date, series$Close, type = "l", col = "#234D70", lwd = 1.5,
                 xlab = "Trading date", ylab = "Daily close (USD)",
                 main = paste(symbol, "daily close and", result$summary$SMAWindow, "day SMA"))
  graphics::lines(series$Date, series$SMA, col = "#C35A21", lwd = 2)
  graphics::legend("topleft", legend = c("Close", "Simple moving average"),
                   col = c("#234D70", "#C35A21"), lty = 1, lwd = c(1.5, 2), bty = "n")
  invisible(result)
}
