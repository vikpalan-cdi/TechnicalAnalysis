# Run from the Assignment_02 directory.
source("R/functions.R")
require_analysis_packages()
dir.create("output", showWarnings = FALSE)
writeLines("RUNNING - outputs are not a certified completed run", "output/run_status.txt")
from <- "2025-01-01"
to <- "2026-01-01"  # exclusive: data are restricted to calendar year 2025
window <- 20L

stocks <- load_stock_data("portfolio.txt", from, to)
utils::write.csv(stocks$manifest, "output/download_manifest.csv", row.names = FALSE)
if (any(stocks$manifest$Status != "OK")) {
  writeLines("FAILED - inspect download_manifest.csv; earlier output files may be stale", "output/run_status.txt")
  stop("At least one download failed. No complete-portfolio result is claimed.")
}
stock_frames <- stocks$data  # e.g. stock_frames[["AAPL"]] is its separate data frame
results <- setNames(lapply(names(stock_frames), function(symbol) {
  calculate_statistics(stock_frames[[symbol]], symbol, window)
}), names(stock_frames))

console_output <- capture.output({
  display_stock_data(stock_frames)
  statistics <- display_statistics(results)
})
writeLines(console_output, "output/console_output.txt")
cat(paste(console_output, collapse = "\n"), "\n")
utils::write.csv(statistics, "output/statistics.csv", row.names = FALSE, na = "NA")
for (symbol in names(stock_frames)) {
  safe_name <- gsub("[^A-Za-z0-9.-]", "_", symbol)
  utils::write.csv(stock_frames[[symbol]], file.path("output", paste0(safe_name, "_daily.csv")), row.names = FALSE)
  utils::write.csv(results[[symbol]]$series, file.path("output", paste0(safe_name, "_sma.csv")), row.names = FALSE, na = "NA")
  plot_stock_data(results[[symbol]], symbol,
                  file.path("output", paste0(safe_name, "_close_sma.png")))
}
writeLines(c(paste("Retrieved at", format(Sys.time(), tz = "UTC", usetz = TRUE)),
             paste("Requested interval", from, "inclusive to", to, "exclusive"),
             "Provider Yahoo Finance via quantmod; daily Close in USD; SMA window 20 trading observations",
             capture.output(sessionInfo())), "output/session_info.txt")
writeLines("SUCCESS - inspect exported data, statistics, plots, and session_info.txt", "output/run_status.txt")
cat("\nOutput saved in output/. Check run_status.txt and download_manifest.csv.\n")
if (interactive()) {
  display_stock_data(stock_frames, viewer = TRUE)
  for (symbol in names(results)) plot_stock_data(results[[symbol]], symbol)
}
