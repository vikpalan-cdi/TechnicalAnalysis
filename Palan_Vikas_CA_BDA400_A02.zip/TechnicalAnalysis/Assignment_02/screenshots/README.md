# Screenshot evidence to capture

Capture actual screens only. Do not substitute example screens for work performed on this computer. The report is not evidence-complete until the relevant screenshots are inserted and captioned.

1. `01_repository.png`: new TechnicalAnalysis repository showing your account and URL.
2. `02_r_download.png`: official R download page and chosen Windows installer.
3. `03_r_installation.png`: actual installation steps and completion, or documented existing installation.
4. `04_rstudio_installation.png`: actual RStudio installation steps and completion. This step is currently deferred.
5. `05_rstudio_session.png`: open project and R console identifying the R version.
6. `06_packages.png`: successful package installation/load output and printed package versions.
7. `07_portfolio.png`: portfolio.txt open with the three symbols.
8. `08_imported_frames.png`: stock_frames entries and first/latest rows for each stock.
9. `09_statistics.png`: statistics table including mode status and latest SMA.
10. `10_charts.png`: actual closing-price and SMA charts for each stock.
11. `11_checks.png`: successful tests plus date/version information; capture failures truthfully if present.
12. `12_final_repository.png`: uploaded Assignment_02 folder and report in TechnicalAnalysis.

Use multiple images where needed to show every installation step. Add numbered captions in Word explaining what each screen proves. Hide unrelated tabs, account secrets, and personal information before capturing.
