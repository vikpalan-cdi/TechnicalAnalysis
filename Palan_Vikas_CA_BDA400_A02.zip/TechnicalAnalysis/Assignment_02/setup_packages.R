# Run once in RStudio; installs only missing dependencies.
packages <- c("quantmod", "TTR", "xts", "zoo")
missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) install.packages(missing, repos = "https://cloud.r-project.org")
for (package in packages) {
  if (!requireNamespace(package, quietly = TRUE)) stop("Installation unsuccessful: ", package)
}
print(sapply(packages, function(package) as.character(utils::packageVersion(package))))
sessionInfo()
