# Known-value checks. No stock download is needed, but R and the packages are required.
source("R/functions.R")
require_analysis_packages()
expect_error <- function(expression) {
  failed <- tryCatch({ force(expression); FALSE }, error = function(e) TRUE)
  stopifnot(failed)
}
fixture <- data.frame(Date = as.Date("2025-01-01") + 0:5,
                      Close = c(10, 10, 20, 30, 30, 50))
r <- calculate_statistics(fixture, "FIXTURE", window = 3)
stopifnot(isTRUE(all.equal(r$summary$MeanClose, 25)),
          isTRUE(all.equal(r$summary$MedianClose, 25)),
          isTRUE(all.equal(r$summary$SampleSDClose, sqrt(230))),
          identical(statistical_mode(fixture$Close), c(10, 30)),
          length(statistical_mode(c(1, 2, 3))) == 0L,
          all(is.na(r$series$SMA[1:2])),
          isTRUE(all.equal(r$series$SMA[3:6], c(40/3, 20, 80/3, 110/3))))
expect_error(calculate_statistics(fixture, "FIXTURE", 7))
expect_error(calculate_statistics(fixture, "FIXTURE", 0))
bad <- fixture; bad$Close[3] <- NA_real_
expect_error(calculate_statistics(bad, "FIXTURE", 3))
bad <- fixture[6:1, ]
expect_error(calculate_statistics(bad, "FIXTURE", 3))

portfolio <- tempfile(fileext = ".txt")
writeLines(c("aapl", "MSFT", "AAPL", "# comment", ""), portfolio)
stopifnot(identical(read_portfolio(portfolio), c("AAPL", "MSFT")))
mock_fetcher <- function(symbol, from, to) {
  if (symbol == "MSFT") stop("Deliberate test failure")
  x <- xts::xts(cbind(Open = fixture$Close, High = fixture$Close + 1,
                      Low = fixture$Close - 1, Close = fixture$Close,
                      Volume = rep(100, 6), Adjusted = fixture$Close),
                order.by = fixture$Date)
  colnames(x) <- paste(symbol, colnames(x), sep = ".")
  x
}
loaded <- load_stock_data(portfolio, "2025-01-02", "2025-01-06", mock_fetcher)
stopifnot(identical(names(loaded$data), "AAPL"),
          is.data.frame(loaded$data$AAPL), nrow(loaded$data$AAPL) == 4L,
          identical(loaded$manifest$Status, c("OK", "FAILED")),
          max(loaded$data$AAPL$Date) < as.Date("2025-01-06"))
writeLines(character(), portfolio)
expect_error(read_portfolio(portfolio))
cat("All known-value, edge-case, portfolio, and mock-download checks passed.\n")
