# TechnicalAnalysis

BDA400 course repository for Vikas Palan. Keep each assignment in its own subdirectory.

## Assignment 2

Open `Assignment_02/README.md` for the preliminary-stage technical analysis project. The folder contains the Word report, portfolio, analysis functions, display code, and checks.

The intended repository address is https://github.com/vikpalan-cdi/TechnicalAnalysis . Creation and upload have not been performed or verified. This is a separate repository from `markdown-buddy-vikaspalan` used for Assignment 1.
